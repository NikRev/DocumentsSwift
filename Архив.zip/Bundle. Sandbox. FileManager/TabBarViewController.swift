import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let VC = ViewController()
        let settingsViewController = SettingsViewController()

        let filesTabBarItem = UITabBarItem(tabBarSystemItem: .downloads, tag: 0)
        let settingsTabBarItem = UITabBarItem(tabBarSystemItem: .more, tag: 1)

        VC.tabBarItem = filesTabBarItem
        settingsViewController.tabBarItem = settingsTabBarItem

        viewControllers = [VC, settingsViewController]
    }
}
